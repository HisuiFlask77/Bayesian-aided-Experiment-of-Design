% 读取数据
initial_data = readtable('initial_data.xlsx','Sheet',1);
no_of_exp = 40;

for i = 20:59

    % 提取前i行数据
    X = initial_data{1:i,1:5};
    y = initial_data{1:i,6};
    z = initial_data{1:i,7};

    % 构建高斯过程模型，核函数为 Matern 5/2
    gprMdl1 = fitrgp(X, y, 'KernelFunction','matern52');
    gprMdl2 = fitrgp(X, z, 'KernelFunction','matern52');
    
    pred = initial_data{i+1,1:5};

    % 预测均值和标准差
    [ypred, ysd] = predict(gprMdl1, pred);
    [zpred, zsd] = predict(gprMdl2, pred);

    initial_data{i+1,8} = ypred;
    initial_data{i+1,9} = ysd;
    initial_data{i+1,10} = zpred;
    initial_data{i+1,11} = zsd;
end


% 将更新后的数据写回 Excel 文件
% 第8-9列为第6列数据的预测值与标准差；第10-11列为第7列数据的预测值与标准差
writetable(initial_data,'initial_data.xlsx','Sheet',1);